# 📜 MeeChain MeeBot | Project Manifest v4.1

ยินดีต้อนรับสู่โปรโตคอลการจัดการ MeeBot อย่างเป็นระเบียบ นี่คือเอกสารหลักในการควบคุมทิศทางการพัฒนาและมาตรฐานของระบบ

---

## 🏛️ System Architecture

1. **State Management:** ใช้ `AppState.tsx` (React Context) เป็นแหล่งข้อมูลความจริงเดียว (Single Source of Truth)
2. **Blockchain Interface:** ใช้ `viem` และ `wagmi` ในการเชื่อมต่อกับ BNB Smart Chain (BSC)
3. **Error Monitoring:** ใช้ `Rollbar` เพื่อดักจับและวิเคราะห์ข้อผิดพลาดแบบ Real-time
4. **Visual Style:** ใช้ **"Mystical High-Tech"** (Glassmorphism + Amber/Sky Blue accents)

---

## ⚔️ Standard Rituals (Protocols)

- **MINT:** ต้องมีการตรวจสอบ Watermark และ Metadata ก่อนการ Anchor
- **STAKE:** ต้องรักษาสมดุลของ MCB Flux และ Neural Stability
- **SUMMON:** ต้องมีระบบ Resonance Pity ที่โปร่งใสและตรวจสอบได้

---

## 🛡️ Stability Standards

- ทุกฟังก์ชันที่เรียกใช้ Smart Contract ต้องห่อหุ้มด้วย `try/catch` และส่ง Log ไปยัง `logger.error`
- ห้ามใช้ `console.log` ในโค้ดการผลิต (Production) ให้ใช้ `logger.info` แทน
- UI ต้องรองรับสภาวะ "Neural Disconnect" (Offline/Wrong Network) อย่างสวยงาม

---
&copy; 2025 MeeChain Protocol Management Team
