
# 🛡️ MeeChain MeeBot | Rollbar Setup & Monitoring Guide

คู่มือสำหรับการตรวจสอบและติดตามข้อผิดพลาดในแอปพลิเคชัน MeeBot Protocol เพื่อความเสถียรสูงสุดของระบบ Manifestation

---

## 🔐 ข้อมูลโทเค็นการเข้าถึง (Access Tokens)

| ประเภทโทเค็น | ค่าโทเค็น | หน้าที่และการใช้งาน | ความปลอดภัย |
|---------------|------------|----------------|----------------|
| **Client Token** | `1d6379b7fbb5403b8cf07e4a9c4889e2` | ใช้ในฝั่งไคลเอนต์ (Browser) สำหรับรายงาน Error จากหน้าเว็บ | สาธารณะ |
| **Server Token** | `e9fcfe044ebf4e7eb60ed8b519b48af0` | ใช้สำหรับงานหลังบ้าน (Admin/Internal Scripts) | **ความลับ** |

---

## 🧾 รายการตรวจสอบคุณภาพ (QA Checklist)

ก่อนทำการ Deployment หรือเริ่มการพัฒนาฟีเจอร์ใหม่ โปรดตรวจสอบสิ่งต่อไปนี้:

- [ ] **Global Error Catching:** ตรวจสอบว่า `index.html` มี Rollbar Snippet ที่ถูกต้อง
- [ ] **Logging Centralization:** ตรวจสอบว่ามีการเรียกใช้ `logger` จาก `@/lib/logger` แทน `console.log` ทั่วไป
- [ ] **Blockchain Error Tracking:** ข้อผิดพลาดจากการเรียกสัญญาอัจฉริยะ (Contract Calls) ต้องถูกบันทึกลง Rollbar ผ่าน `logger.error`
- [ ] **AI Telemetry:** การทำนายของ Oracle ที่ผิดพลาดต้องถูกรายงานเพื่อวิเคราะห์ความแม่นยำ
- [ ] **Network Integrity:** ตรวจสอบว่าระบบแจ้งเตือนเมื่ออยู่ผิด Network ทำงานร่วมกับ Rollbar ได้ถูกต้อง

---

## 🛠️ วิธีการใช้งานในโค้ด

### สำหรับนักพัฒนา
ใช้ `logger` ยูทิลิตี้ที่เราเตรียมไว้เพื่อให้ระบบมีความเป็นระเบียบ:

```typescript
import { logger } from '../lib/logger';

// สำหรับข้อมูลทั่วไป
logger.info('User opened the portal');

// สำหรับข้อผิดพลาดสำคัญ
try {
  // logic...
} catch (error) {
  logger.error('Summoning failed due to gas issues', error);
}

// สำหรับการติดตาม Ritual (Custom Events)
logger.ritual('MINT_BOT', true, { botId: '123', rarity: 'Legendary' });
```

---

## 📡 การตรวจสอบผ่าน Dashboard
คุณสามารถเข้าถึงข้อมูลการวิเคราะห์และข้อผิดพลาดทั้งหมดได้ที่:
[Rollbar Dashboard - MeeBot Project](https://rollbar.com/)

*&copy; 2025 MeeChain Protocol Security Team*
